#include "System.h"

int main()
{
    System::i().run();

    return 0;
}